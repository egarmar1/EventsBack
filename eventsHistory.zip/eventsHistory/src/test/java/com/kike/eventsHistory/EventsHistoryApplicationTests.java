package com.kike.eventsHistory;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EventsHistoryApplicationTests {

	@Test
	void contextLoads() {
	}

}
