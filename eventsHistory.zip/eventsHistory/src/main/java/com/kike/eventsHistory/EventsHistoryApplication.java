package com.kike.eventsHistory;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EventsHistoryApplication {

	public static void main(String[] args) {
		SpringApplication.run(EventsHistoryApplication.class, args);
	}

}
